# Lidomare Design System

> Lidomare Health App · Powered by Antifrágil® · Playamar, Torremolinos

A pocket-sized PWA for members of **Lidomare Health & Fitness Club** (Spanish boutique health & training club). Members log in, follow a personalized training plan (rutinas), log sessions, track their weekly streak, watch exercise / activation / podcast / webinar content, and book appointments via Salonized / WhatsApp. Admin ships invites via Resend. Content is pulled from Notion; auth + data live in Supabase.

The entire app is designed as a **single 430px-wide pane on pure black** with a *liquid-glass* aesthetic (frosted translucent cards on ambient turquoise / indigo radial blobs).

---

## Product surface
- One product, one surface: the **mobile PWA** at `app-lidomare.vercel.app` (Next.js 16, React 19, Tailwind 4, Supabase, Notion, Resend).
- Key screens: Login → Home (welcome + week calendar + streak + next workout) → Rutinas (routines CRUD + trainer) → Contenido (content library: Ejercicio, Activación, Podcast, Webinars) → Citas (booking via Salonized / WhatsApp) → Perfil (profile + progress).

## Sources
- **Codebase:** `carlosvf42-cell/AppLidomare` (private GitHub, Next.js App Router). Key files read: `app/globals.css`, `app/layout.tsx`, `app/(app)/layout.tsx`, `app/(app)/page.tsx`, `app/(app)/contenido/page.tsx`, `app/(app)/citas/page.tsx`, `app/(app)/perfil/page.tsx`, `app/(app)/rutinas/page.tsx`, `app/login/page.tsx`, `components/BottomNav.tsx`, `components/Logo.tsx`, `components/SplashScreen.tsx`, `components/VideoModal.tsx`, `components/ContentStates.tsx`, `public/manifest.json`.
- No Figma, no slide decks provided.

---

## Index
- `colors_and_type.css` — design tokens (colors, type, glass, radii, shadows, tracking)
- `assets/` — logo.svg, logo-mark.svg
- `preview/` — card specimens registered to the Design System tab
- `ui_kits/app/` — React recreations of the mobile PWA (Login, Home, Contenido, Citas, Perfil) with `index.html` click-thru
- `SKILL.md` — skill manifest for Claude Code / Agent Skills

---

## Content Fundamentals

**Language:** Spanish (es-ES). Informal "tú", never "usted". Warm but restrained; never hype.

**Tone:** *Clinical-calm-premium.* Feels like a physiotherapist who also designs watches. Copy is short, declarative, and a touch cold. Motivation is conveyed through **terseness + a turquoise accent**, not exclamation marks.

**Casing:**
- **ALL-CAPS micro labels everywhere** with 0.2–0.4em letter-spacing (e.g. `BIENVENIDO DE NUEVO`, `SEMANA ACTUAL`, `RACHA ACTUAL`, `ENTRENAR AHORA →`, `SEC_CONN: ACTIVE`). This is the defining typographic signature.
- Sentence case for body + headings (`Mi Rutina`, `Reservar cita`).
- Nav labels are **lowercase** (`home`, `contenido`, `citas`, `perfil`).

**Pronouns:** "tú / tu / tus". "Tu rutina", "tu entrenador", "tus reservas".

**Emoji usage:** **Extremely rare.** Found only once in the codebase: a single `💪` in the "Semana completada 💪" success state. Do **not** add emoji — treat the existing `💪` as a one-off Easter egg.

**Micro-copy examples (verbatim):**
- `Bienvenido de nuevo`
- `Semana actual` / `Racha actual` / `Próximo entrenamiento`
- `Entrenar ahora →` / `Entrenar hoy` / `Crear mi rutina`
- `Entrena esta semana para empezar` / `Buen comienzo` / `Muy bien, sigue así` / `Imparable`
- `Descansa y vuelve la próxima semana`
- `Gestiona tus reservas online →` / `Contacta con tu entrenador →`
- `Precision Wellness` (English tagline under the wordmark)
- `LM · PLAYAMAR · TORREMOLINOS` / `SEC_CONN: ACTIVE` (decorative terminal-style footer on login)
- Error: `Email o contraseña incorrectos.` / `No se pudo cargar el contenido.`
- Empty: `Aún no tienes una rutina activa` / `No hay episodios disponibles.`

**Vibe:** *spa / labcoat / night-drive.* Quiet typography. The interface speaks in whispers; turquoise is the only raised voice.

---

## Visual Foundations

### Colors
Black ground (`#000`, `#080808`, `#0a0a0a` for shell/splash/card), a **white-alpha ramp** for every text tier (0.92 → 0.12) plus a parallel **near-black ramp** (`#555 → #1a1a1a`) for labels on dark cards, and exactly **one** chromatic accent: **turquoise `#2abfbf`**. Indigo `rgba(99,102,241,0.22)` appears **only** as an ambient radial blob in the home background — never on UI elements.

### Type
- **Inter** (300/400/500/600) — 100% of UI text.
- **Cormorant Garamond** (via `--font-cormorant`) — display serif, used for the `HEALTH APP` hero on login/splash.
- **Barlow Condensed** 800 — chunky condensed display, used only on `/citas` card titles (`RESERVAR CITA`, `ASESORAMIENTO PERSONAL`).
- Letter-spacing is used as a brand gesture: 0.1em → 0.4em tracking on small all-caps labels.
- Heading sizes skew **small** (24–32px). Display numerals (streak count) sit at 28px. Body is 12–14px.

### Backgrounds
- **Full-bleed black** everywhere. No patterns, no photos except:
  - `/images/hero-home.jpg` — single editorial photo at the top of Home, 280px tall, faded into black via a vertical gradient.
- **Ambient radial blobs:** 3–4 large, blurred (70–120px), low-alpha turquoise circles positioned off-canvas. Indigo blob used sparingly.
- No hand-drawn illustrations, no repeating patterns, no noise/grain.

### Glass / surfaces
Two glass tiers:
1. **Heavy glass** (hero cards): `rgba(255,255,255,0.07)` + `backdrop-filter: blur(24px) saturate(180%)` + `0.5px` inner border `rgba(255,255,255,0.13)` + `inset 0 1px 0 rgba(255,255,255,0.10), 0 4px 24px rgba(0,0,0,0.4)`.
2. **Light glass** (secondary rows): `rgba(255,255,255,0.03)` + `blur(10px)` + `0.5px` border `rgba(255,255,255,0.08)`.

Nav has its own recipe: `rgba(0,0,0,0.55)` + `blur(40px) saturate(180%)`.

### Borders
**`0.5px` hairlines are a brand choice** (`var(--hair)`). Used for every card border, input underline, separator. 1px borders are reserved for iconography strokes. No thick borders anywhere.

### Radii
Aggressive mobile radii: `4, 6, 12, 16, 20, 24, 28`. Pills (`9999`) for chips. CTAs use `6` (small) or `16` (rectangular big). Cards use `16`, `20`, `24`. Avatars/icons: `16` or `full`.

### Shadows
Two systems:
- **Inset highlight + outer drop** on glass: `inset 0 1px 0 rgba(255,255,255,0.10), 0 4px 24px rgba(0,0,0,0.4)`.
- **Turquoise glow** on primary CTA: `0 4px 20px rgba(42,191,191,0.35)` + inset white highlight.

### Animation
- **Fade + spinners** only. No bouncy motion, no parallax, no scroll-linked effects.
- Splash shimmer: a turquoise line sweeps across a 100×0.5px track over 1.4s ease-in-out.
- Buttons use CSS transitions for opacity / transform only.
- **No entry animations** on page loads.

### Hover / Press
- **Hover:** near-imperceptible (opacity drop or border brighten). The app is mobile-first; hover is not a primary channel.
- **Press:** `active:scale-[0.98]` everywhere — this is the universal "tapped" gesture. Paired with a `transition-transform` / `transition-all`.

### Transparency & blur
Used **constantly and intentionally**. Blur always pairs with `saturate(180%)` on hero surfaces. Every dialog/nav/card is either solid-dark or glass — no flat grays.

### Imagery
- **Cool, low-key, editorial.** The single in-app photo is dark, desaturated, high-contrast, with a black gradient baked in. Any added imagery should match this: cool tones, shadowed, no warmth, no grain.

### Layout rules
- **430px max-width shell** centered, scrolls inside.
- Bottom nav is **fixed**, 62px + safe-area inset, full-bleed glass.
- Padding rhythm: `px-4` (16px) for card columns, `px-5` / `px-6` for headers, `pt-14` for top-of-page breathing room.
- Safe-area respected via `env(safe-area-inset-bottom)`.

### Cards
- Large rounding (20–28px).
- Glass fill, hairline border, inset highlight, soft outer shadow.
- Content order almost always: **eyebrow (turquoise caps)** → title → body → CTA / meta row.

---

## Iconography

- **Style:** Inline SVG, hand-authored per-icon in `components/BottomNav.tsx` and inline in page files. Uniform 22×22 viewBox, `stroke-width: 1.4`, `stroke-linecap="round"`, `stroke-linejoin="round"`. No fills except play triangles and checkmarks.
- **Stroke color follows state:** active = `#2abfbf`, inactive = `rgba(255,255,255,0.35)`.
- **No icon font, no sprite, no Lucide / Heroicons dependency.** Icons are bespoke and per-file.
- **No PNG icons** in the product.
- **Emoji:** essentially unused (one `💪` Easter egg — see Content Fundamentals).
- **Unicode glyphs:** yes — decorative `·`, `✦`, `→`. `→` is the brand's preferred "go" marker. `·` joins metadata (`LM · PLAYAMAR · TORREMOLINOS`). `✦` appears in the logo only.

**Substitution note:** Since there is no icon set to import, the UI kit re-authors each icon inline in JSX matching the 22×22 / 1.4 stroke recipe. When extending Lidomare with new icons, match this recipe exactly; don't pull in Lucide etc. (it won't match the `1.4` stroke + `0.5` hairline language).

---

## Font substitution flag
The app uses `next/font/google` to load **Inter**, and references `--font-cormorant` (Cormorant Garamond) that is declared in code but **not wired in `app/layout.tsx`** — it's inherited from the Google Fonts default stack / Georgia fallback. This design system ships with both Inter and Cormorant Garamond loaded from Google Fonts. **Barlow Condensed** is also loaded via Google Fonts for the `/citas` hero titles. If you have licensed versions of any of these, drop them into `fonts/` and we'll wire them locally.

---

## Caveats
- No Figma / no brand style guide was provided — everything here is reverse-engineered from the codebase.
- The hero image `/images/hero-home.jpg` is referenced in code but not present in `public/` — we use a placeholder gradient in the UI kit.
- PWA icons `/icons/icon-192.png` and `/icons/icon-512.png` are referenced in `manifest.json` but also missing from the repo.
- The bespoke inline SVG icons were rewritten in the UI kit from the originals; strokes / proportions match, but pixel-for-pixel diffs vs. production are possible.
