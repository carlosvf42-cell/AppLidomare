function HomeV2({ photoSrc, go }) {
  const labels = ["L","M","X","J","V","S","D"];
  const days = [
    { n: 14, done: true }, { n: 15, done: true }, { n: 16, today: true, started: true },
    { n: 17 }, { n: 18 }, { n: 19 }, { n: 20 },
  ];
  const stats = [
    { k: "MIN",    v: "42" },
    { k: "KCAL",   v: "384" },
    { k: "SERIES", v: "18" },
  ];

  return (
    <div>
      {/* Hero: foto + gradient + título grande */}
      <div style={{ position: "relative", height: 380, overflow: "hidden" }}>
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: `url(${photoSrc})`,
          backgroundSize: "cover", backgroundPosition: "center 35%",
          transform: "scale(1.05)",
        }}/>
        {/* Color grade toward turquoise */}
        <div style={{ position: "absolute", inset: 0,
          background: "linear-gradient(135deg, rgba(42,191,191,0.18) 0%, transparent 40%, rgba(0,0,0,0.3) 100%)",
          mixBlendMode: "overlay",
        }}/>
        <div style={{ position: "absolute", inset: 0,
          background: "linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, transparent 35%, rgba(0,0,0,0.55) 65%, #000 100%)",
        }}/>

        {/* Top meta */}
        <div style={{ position: "absolute", top: 60, left: 20, right: 20, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div style={{ maxWidth: 240 }}>
            <Eyebrow>Lidomare · Antifrágil®</Eyebrow>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", marginTop: 6,
              textShadow: "0 1px 6px rgba(0,0,0,0.6)" }}>Miércoles, 16 de abril</div>
          </div>
          <div style={{
            width: 40, height: 40, borderRadius: "50%",
            ...glassLight(),
            display: "flex", alignItems: "center", justifyContent: "center",
            color: ACCENT_TURQ, fontSize: 12, fontWeight: 500, letterSpacing: "0.05em",
          }}>CA</div>
        </div>

        {/* Big title */}
        <div style={{ position: "absolute", left: 20, right: 20, bottom: 24 }}>
          <MetaLabel>Bienvenido de nuevo</MetaLabel>
          <div style={{
            fontSize: 56, fontWeight: 200, lineHeight: 0.95, letterSpacing: "-0.02em",
            color: "#fff", marginTop: 6,
            fontFamily: "'Cormorant Garamond', Georgia, serif",
          }}>Carlos<span style={{ color: ACCENT_TURQ }}>.</span></div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", marginTop: 10, lineHeight: 1.5, maxWidth: 300 }}>
            Hoy toca <span style={{ color: ACCENT_TURQ }}>Día 2 · Empuje</span>. 42 minutos estimados.
          </div>
        </div>
      </div>

      <div style={{ padding: "18px 16px 24px", display: "flex", flexDirection: "column", gap: 16, position: "relative" }}>

        {/* Lens card — Próximo entrenamiento (HERO component) */}
        <div style={{
          position: "relative", borderRadius: 28, padding: 22, overflow: "hidden",
          ...glassLens(),
        }}>
          <LensSheen angle={135}/>
          {/* chromatic blob inside */}
          <div aria-hidden style={{
            position: "absolute", top: -40, right: -40, width: 160, height: 160, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(42,191,191,0.30) 0%, transparent 70%)",
            filter: "blur(20px)",
          }}/>
          <div aria-hidden style={{
            position: "absolute", bottom: -30, left: -30, width: 130, height: 130, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(123,140,255,0.18) 0%, transparent 70%)",
            filter: "blur(20px)",
          }}/>

          <div style={{ position: "relative", zIndex: 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Eyebrow>Próximo entrenamiento</Eyebrow>
              <span style={{
                fontSize: 9, letterSpacing: "0.18em", textTransform: "uppercase",
                color: "rgba(255,255,255,0.4)",
                background: "rgba(255,255,255,0.05)", padding: "3px 8px",
                borderRadius: 999, border: "0.5px solid rgba(255,255,255,0.1)",
              }}>Full body · Int.</span>
            </div>
            <div style={{
              fontSize: 32, fontWeight: 300, color: "#fff", marginTop: 10,
              fontFamily: "'Cormorant Garamond', Georgia, serif", lineHeight: 1,
              letterSpacing: "-0.01em",
            }}>Día 2 · Empuje</div>

            {/* Stats row */}
            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              {stats.map(s => (
                <div key={s.k} style={{
                  flex: 1, borderRadius: 14, padding: "10px 12px",
                  background: "rgba(0,0,0,0.28)",
                  border: "0.5px solid rgba(255,255,255,0.08)",
                }}>
                  <div style={{ fontSize: 22, fontWeight: 600, color: "#fff", lineHeight: 1,
                    fontFeatureSettings: "'tnum'", letterSpacing: "-0.01em" }}>{s.v}</div>
                  <div style={{ fontSize: 8, letterSpacing: "0.22em", color: "rgba(255,255,255,0.35)",
                    textTransform: "uppercase", marginTop: 4 }}>{s.k}</div>
                </div>
              ))}
            </div>

            {/* Exercise list */}
            <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 6 }}>
              {[
                ["Press banca",           "4×8"],
                ["Press militar",         "4×10"],
                ["Fondos en paralelas",   "3×12"],
                ["Elevaciones laterales", "3×15"],
              ].map(([n, s], i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between",
                  fontSize: 12, color: "rgba(255,255,255,0.6)",
                  paddingBottom: 6,
                  borderBottom: i < 3 ? "0.5px solid rgba(255,255,255,0.05)" : "none",
                }}>
                  <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{
                      width: 16, height: 16, borderRadius: 4,
                      background: "rgba(42,191,191,0.08)",
                      border: "0.5px solid rgba(42,191,191,0.25)",
                      color: ACCENT_TURQ, fontSize: 9, fontWeight: 600,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontFeatureSettings: "'tnum'",
                    }}>{i+1}</span>
                    {n}
                  </span>
                  <span style={{ color: "rgba(255,255,255,0.4)", fontFeatureSettings: "'tnum'" }}>{s}</span>
                </div>
              ))}
            </div>

            <PrimaryBtn onClick={() => go("sesion")} style={{ marginTop: 20 }}
              icon={<IconPlay c="#001a1a" size={14}/>}>
              Entrenar ahora
            </PrimaryBtn>
          </div>
        </div>

        {/* Week calendar */}
        <div style={{ borderRadius: 24, padding: "16px 18px", ...glassHeavy() }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <Eyebrow>Semana actual</Eyebrow>
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", fontFeatureSettings: "'tnum'" }}>2 / 7 completados</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            {days.map((d, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 14,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 13, fontWeight: 500, fontFeatureSettings: "'tnum'",
                  background: d.done ? `linear-gradient(180deg, rgba(42,191,191,0.25), rgba(42,191,191,0.08))`
                           : d.today ? "rgba(42,191,191,0.05)" : "rgba(255,255,255,0.02)",
                  border: d.done ? "0.5px solid rgba(42,191,191,0.55)"
                        : d.today ? "1px solid rgba(42,191,191,0.5)"
                        : "0.5px solid rgba(255,255,255,0.08)",
                  color: d.done ? "#fff" : d.today ? ACCENT_TURQ : "rgba(255,255,255,0.3)",
                  boxShadow: d.done ? "inset 0 1px 0 rgba(255,255,255,0.15), 0 2px 10px rgba(42,191,191,0.15)" : "none",
                }}>{d.n}</div>
                <span style={{ fontSize: 8, color: "rgba(255,255,255,0.25)", letterSpacing: "0.08em" }}>{labels[i]}</span>
                <div style={{ height: 10, display: "flex", alignItems: "center" }}>{d.done && <IconCheck/>}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Racha + progreso fila */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div style={{ ...glassLight(), borderRadius: 20, padding: 16, position: "relative", overflow: "hidden" }}>
            <LensSheen/>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <IconFlame/>
              <Eyebrow>Racha</Eyebrow>
            </div>
            <div style={{ fontSize: 36, fontWeight: 300, color: "#fff", marginTop: 10, lineHeight: 1,
              fontFamily: "'Cormorant Garamond', serif", fontFeatureSettings: "'tnum'" }}>
              3<span style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginLeft: 6,
                fontFamily: "'Inter', sans-serif", letterSpacing: "0.05em" }}>sem</span>
            </div>
            <div style={{ fontSize: 10.5, color: ACCENT_TURQ, marginTop: 4, letterSpacing: "0.05em" }}>
              Muy bien, sigue así
            </div>
          </div>

          <div style={{ ...glassLight(), borderRadius: 20, padding: 16, position: "relative", overflow: "hidden" }}>
            <LensSheen/>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <IconBolt/>
              <Eyebrow>Mes</Eyebrow>
            </div>
            <div style={{ fontSize: 36, fontWeight: 300, color: "#fff", marginTop: 10, lineHeight: 1,
              fontFamily: "'Cormorant Garamond', serif", fontFeatureSettings: "'tnum'" }}>12</div>
            <div style={{ fontSize: 10.5, color: "rgba(255,255,255,0.5)", marginTop: 4, letterSpacing: "0.05em" }}>
              <span style={{ color: ACCENT_TURQ }}>+3</span> vs mes anterior
            </div>
          </div>
        </div>

        {/* Shortcut chips */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4, marginLeft: -4, marginRight: -4, padding: "0 4px" }}>
          {[
            { l: "Reservar cita",  sub: "Salonized"},
            { l: "Activación",     sub: "Movilidad"},
            { l: "Hablar con coach", sub: "WhatsApp"},
          ].map((c, i) => (
            <button key={i} style={{
              flex: "0 0 auto", ...glassLight(), borderRadius: 18, padding: "12px 14px",
              border: "0.5px solid rgba(255,255,255,0.08)", cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "flex-start", minWidth: 150,
            }}>
              <span style={{ fontSize: 8, letterSpacing: "0.22em", color: ACCENT_TURQ, textTransform: "uppercase" }}>{c.sub}</span>
              <span style={{ fontSize: 13, color: "#fff", marginTop: 4 }}>{c.l}</span>
            </button>
          ))}
        </div>

        <p style={{ textAlign: "center", fontSize: 9, letterSpacing: "0.18em",
          color: "rgba(255,255,255,0.12)", margin: "12px 0 0", textTransform: "uppercase" }}>
          Lidomare · Playamar
        </p>
      </div>
    </div>
  );
}
Object.assign(window, { HomeV2 });
