function ContenidoV2({ go }) {
  const featured = {
    cat: "ENTRENAMIENTO",
    title: "Full Body · Bloque 3",
    subtitle: "12 semanas · Intermedio",
    cover: "linear-gradient(135deg, #1a3a3a 0%, #0a1a20 50%, #0a0a1a 100%)",
  };
  const sections = [
    { cat: "Ejercicio",   t: "Ejercicio Terapéutico", s: "Protocolos de rehabilitación",   count: "24 vídeos",
      tint: "rgba(42,191,191,0.14)", accent: ACCENT_TURQ },
    { cat: "Activación",  t: "Activación y Movilidad", s: "Calentamiento y preparación",    count: "18 vídeos",
      tint: "rgba(123,140,255,0.14)", accent: ACCENT_INDIGO },
    { cat: "Podcast",     t: "Conversaciones Antifrágil", s: "Episodios sobre salud y rendimiento",  count: "8 episodios",
      tint: "rgba(42,191,191,0.10)", accent: ACCENT_TURQ },
    { cat: "Webinar",     t: "Webinars",        s: "Sesiones formativas en directo",       count: "Próximamente",
      tint: "rgba(255,255,255,0.04)", accent: "rgba(255,255,255,0.5)", locked: true },
  ];

  return (
    <div style={{ paddingBottom: 24 }}>
      <div style={{ padding: "56px 20px 8px" }}>
        <Eyebrow color="rgba(255,255,255,0.3)">Biblioteca</Eyebrow>
        <h1 style={{
          fontSize: 40, fontWeight: 200, letterSpacing: "-0.02em",
          color: "#fff", margin: "6px 0 0",
          fontFamily: "'Cormorant Garamond', Georgia, serif",
        }}>Contenido</h1>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 8, lineHeight: 1.5 }}>
          Tus rutinas, protocolos y formación — todo en un sitio.
        </p>
      </div>

      {/* Search-ish chip row */}
      <div style={{ padding: "16px 16px 0", display: "flex", gap: 8, overflowX: "auto" }}>
        {["Todo", "Entrenamiento", "Rehab", "Movilidad", "Podcast"].map((t, i) => (
          <button key={t} style={{
            flex: "0 0 auto", padding: "8px 14px", borderRadius: 999,
            background: i === 0 ? "rgba(42,191,191,0.12)" : "rgba(255,255,255,0.03)",
            border: `0.5px solid ${i === 0 ? "rgba(42,191,191,0.4)" : "rgba(255,255,255,0.1)"}`,
            color: i === 0 ? ACCENT_TURQ : "rgba(255,255,255,0.55)",
            fontSize: 11, letterSpacing: "0.1em", cursor: "pointer",
            fontFamily: "inherit",
          }}>{t}</button>
        ))}
      </div>

      {/* Featured — big immersive card */}
      <button onClick={() => go("sesion")} style={{
        display: "block", width: "calc(100% - 32px)", margin: "16px auto 0",
        textAlign: "left", background: "none", border: "none", padding: 0, cursor: "pointer",
      }}>
        <div style={{
          position: "relative", height: 220, borderRadius: 28, overflow: "hidden",
          background: featured.cover, ...glassLens(),
        }}>
          <LensSheen angle={130}/>
          <div aria-hidden style={{
            position: "absolute", inset: 0,
            background: "radial-gradient(circle at 75% 25%, rgba(42,191,191,0.35) 0%, transparent 55%)",
          }}/>
          <div aria-hidden style={{
            position: "absolute", inset: 0,
            background: "linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 55%)",
          }}/>
          {/* Decorative rings */}
          <svg aria-hidden style={{ position: "absolute", top: -30, right: -30, opacity: 0.25 }} width="200" height="200" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="30" fill="none" stroke={ACCENT_TURQ} strokeWidth="0.3"/>
            <circle cx="50" cy="50" r="40" fill="none" stroke={ACCENT_TURQ} strokeWidth="0.3"/>
            <circle cx="50" cy="50" r="48" fill="none" stroke={ACCENT_TURQ} strokeWidth="0.3"/>
          </svg>

          <div style={{ position: "absolute", left: 20, right: 20, bottom: 18 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <span style={{
                background: "rgba(42,191,191,0.18)", color: ACCENT_TURQ,
                border: "0.5px solid rgba(42,191,191,0.4)",
                fontSize: 8.5, letterSpacing: "0.22em", textTransform: "uppercase",
                padding: "3px 8px", borderRadius: 999,
              }}>Destacado</span>
              <Eyebrow>{featured.cat}</Eyebrow>
            </div>
            <div style={{
              fontSize: 28, fontWeight: 300, color: "#fff",
              fontFamily: "'Cormorant Garamond', serif", lineHeight: 1,
              letterSpacing: "-0.01em",
            }}>{featured.title}</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", marginTop: 6 }}>
              {featured.subtitle}
            </div>
          </div>
          <div style={{
            position: "absolute", top: 20, left: 20,
            width: 46, height: 46, borderRadius: "50%",
            background: "rgba(0,0,0,0.4)", backdropFilter: "blur(16px)",
            border: "0.5px solid rgba(255,255,255,0.2)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <IconPlay c="#fff" size={14}/>
          </div>
        </div>
      </button>

      {/* Sections list */}
      <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 10 }}>
        {sections.map((s, i) => (
          <button key={i} disabled={s.locked} style={{
            position: "relative", textAlign: "left", background: "none", border: "none", padding: 0,
            cursor: s.locked ? "default" : "pointer", opacity: s.locked ? 0.55 : 1,
          }}>
            <div style={{
              ...glassLight(), borderRadius: 22, padding: "16px 18px",
              display: "flex", alignItems: "center", gap: 14,
              position: "relative", overflow: "hidden",
            }}>
              <LensSheen/>
              <div style={{
                width: 56, height: 56, borderRadius: 18, flexShrink: 0,
                background: s.tint,
                border: `0.5px solid ${s.locked ? "rgba(255,255,255,0.08)" : s.accent + "44"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                position: "relative", overflow: "hidden",
              }}>
                {/* mini decoration by category */}
                {s.cat === "Ejercicio" && (
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                    <path d="M3 12h4l2-6 4 12 2-6h4" stroke={s.accent} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
                {s.cat === "Activación" && (
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="8" stroke={s.accent} strokeWidth="1.3"/>
                    <circle cx="12" cy="12" r="3" stroke={s.accent} strokeWidth="1.3"/>
                    <path d="M12 4v3M12 17v3M4 12h3M17 12h3" stroke={s.accent} strokeWidth="1.3" strokeLinecap="round"/>
                  </svg>
                )}
                {s.cat === "Podcast" && (
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                    <rect x="9" y="3" width="6" height="13" rx="3" stroke={s.accent} strokeWidth="1.3"/>
                    <path d="M5 11v1a7 7 0 0014 0v-1M12 20v2" stroke={s.accent} strokeWidth="1.3" strokeLinecap="round"/>
                  </svg>
                )}
                {s.cat === "Webinar" && <IconLock c={s.accent} size={18}/>}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Eyebrow color={s.accent}>{s.cat}</Eyebrow>
                  {s.locked && (
                    <span style={{
                      background: "rgba(42,191,191,0.08)", border: "0.5px solid rgba(42,191,191,0.3)",
                      color: ACCENT_TURQ, fontSize: 8, letterSpacing: "0.2em", textTransform: "uppercase",
                      borderRadius: 4, padding: "2px 6px",
                    }}>Próximamente</span>
                  )}
                </div>
                <div style={{ fontSize: 15, fontWeight: 500, color: "#fff", marginTop: 4 }}>{s.t}</div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.s}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 6, letterSpacing: "0.1em" }}>{s.count}</div>
              </div>
              {!s.locked && <IconArrow c="rgba(255,255,255,0.4)"/>}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ContenidoV2 });
