function CitasV2() {
  const servicios = [
    {
      key: "fisio", t: "Fisioterapia",
      sub: "Tratamos el origen del dolor, no solo el síntoma.",
      draw: (c) => (<svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M3 12h4l2-7 4 14 2-7h4" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>),
    },
    {
      key: "read", t: "Readaptación",
      sub: "Vuelve al movimiento de forma progresiva.",
      draw: (c) => (<svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M4 12h2M18 12h2M8 7v10M16 7v10M8 12h8" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>),
    },
    {
      key: "nutri", t: "Nutrición",
      sub: "Hábitos reales, sin dietas milagrosas.",
      draw: (c) => (<svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z" stroke={c} strokeWidth="1.3"/>
        <path d="M2 21c0-3 1.85-5.36 5.08-6" stroke={c} strokeWidth="1.3" strokeLinecap="round"/>
      </svg>),
    },
  ];

  return (
    <div style={{ paddingBottom: 24 }}>
      <div style={{ padding: "56px 20px 8px" }}>
        <Eyebrow color="rgba(255,255,255,0.3)">Quiénes somos</Eyebrow>
        <h1 style={{
          fontSize: 46, fontWeight: 200, letterSpacing: "-0.02em",
          color: "#fff", margin: "6px 0 0", lineHeight: 0.95,
          fontFamily: "'Cormorant Garamond', Georgia, serif",
        }}>Antifrágil<span style={{ color: ACCENT_TURQ }}>.</span></h1>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", marginTop: 14, lineHeight: 1.55, maxWidth: 360 }}>
          Tu equipo de salud dentro de Lidomare. Fisioterapeutas, entrenadores y nutricionistas que comparten un objetivo:
          que te muevas mejor, te recuperes más rápido y construyas una salud que dure.
        </p>
      </div>

      {/* Servicios — stacked cards */}
      <div style={{ padding: "20px 16px 0", display: "flex", flexDirection: "column", gap: 8 }}>
        <Eyebrow style={{ paddingLeft: 4, marginBottom: 4 }}>Nuestros servicios</Eyebrow>
        {servicios.map(s => (
          <div key={s.key} style={{
            ...glassLight(), borderRadius: 20, padding: "16px 18px",
            display: "flex", alignItems: "center", gap: 14, position: "relative", overflow: "hidden",
          }}>
            <LensSheen/>
            <div style={{
              width: 48, height: 48, borderRadius: 14,
              background: "rgba(42,191,191,0.08)",
              border: "0.5px solid rgba(42,191,191,0.28)",
              display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
            }}>{s.draw(ACCENT_TURQ)}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, color: "#fff", fontWeight: 500 }}>{s.t}</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", marginTop: 3, lineHeight: 1.4 }}>{s.sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Big CTA: reservar cita */}
      <div style={{ padding: "24px 16px 0" }}>
        <Eyebrow style={{ paddingLeft: 4, marginBottom: 10 }}>Reserva tu cita</Eyebrow>
        <div style={{
          position: "relative", borderRadius: 28, padding: 22, overflow: "hidden",
          ...glassLens(),
        }}>
          <LensSheen angle={135}/>
          <div aria-hidden style={{
            position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(42,191,191,0.35) 0%, transparent 70%)",
            filter: "blur(30px)",
          }}/>
          <div style={{ position: "relative", zIndex: 1 }}>
            <Eyebrow>Salonized</Eyebrow>
            <div style={{
              fontSize: 40, fontWeight: 800, color: "#fff", marginTop: 10,
              textTransform: "uppercase", lineHeight: 0.9,
              fontFamily: "'Barlow Condensed', sans-serif",
              letterSpacing: "-0.01em",
            }}>Reservar<br/>cita</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 12 }}>
              Consulta disponibilidad y reserva online en segundos.
            </div>
            <PrimaryBtn icon={<IconArrow c="#001a1a" size={14}/>} style={{ marginTop: 18 }}>
              Ir a Salonized
            </PrimaryBtn>
          </div>
        </div>
      </div>

      {/* WhatsApp secundario */}
      <div style={{ padding: "12px 16px 0" }}>
        <button style={{
          width: "100%", ...glassLight(), borderRadius: 20, padding: "16px 18px",
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14,
          cursor: "pointer", border: "0.5px solid rgba(123,140,255,0.2)",
          position: "relative", overflow: "hidden",
        }}>
          <div aria-hidden style={{
            position: "absolute", inset: 0,
            background: "radial-gradient(circle at 100% 50%, rgba(123,140,255,0.12), transparent 60%)",
          }}/>
          <div style={{ position: "relative", textAlign: "left", flex: 1 }}>
            <Eyebrow color={ACCENT_INDIGO}>WhatsApp · 24 h</Eyebrow>
            <div style={{ fontSize: 15, color: "#fff", marginTop: 4 }}>Asesoramiento personal</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", marginTop: 2 }}>Escribe a tu entrenador</div>
          </div>
          <div style={{ position: "relative", color: ACCENT_INDIGO }}><IconArrow c={ACCENT_INDIGO}/></div>
        </button>
      </div>

      {/* Horario */}
      <div style={{ padding: "20px 16px 0" }}>
        <div style={{
          ...glassLight(), borderRadius: 20, padding: "14px 18px",
          display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12,
        }}>
          <div>
            <MetaLabel>Horario</MetaLabel>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.85)", marginTop: 6 }}>L–V · 09:00–21:00</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.85)" }}>Sábado · 10:00–14:00</div>
          </div>
          <div>
            <MetaLabel>Ubicación</MetaLabel>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.85)", marginTop: 6 }}>Lidomare Club</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.45)" }}>Playamar · Torremolinos</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PerfilV2({ go, onSignOut }) {
  return (
    <div style={{ paddingBottom: 24 }}>
      <div style={{ padding: "56px 20px 0" }}>
        <Eyebrow color="rgba(255,255,255,0.3)">Perfil</Eyebrow>
      </div>

      {/* Hero: avatar + nombre */}
      <div style={{
        position: "relative", margin: "18px 16px 0", borderRadius: 28, padding: 22,
        overflow: "hidden", ...glassLens(), textAlign: "center",
      }}>
        <LensSheen angle={140}/>
        <div aria-hidden style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(circle at 50% 30%, rgba(42,191,191,0.22), transparent 55%)",
        }}/>
        <div style={{
          position: "relative", width: 80, height: 80, margin: "0 auto", borderRadius: "50%",
          background: "linear-gradient(135deg, rgba(42,191,191,0.35), rgba(123,140,255,0.22))",
          border: "0.5px solid rgba(42,191,191,0.4)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "#fff", fontSize: 26, fontWeight: 300,
          fontFamily: "'Cormorant Garamond', serif", letterSpacing: "0.02em",
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.2)",
        }}>CA</div>
        <div style={{
          position: "relative", fontSize: 24, color: "#fff", marginTop: 14, fontWeight: 300,
          fontFamily: "'Cormorant Garamond', serif", letterSpacing: "-0.01em",
        }}>Carlos Álvarez</div>
        <div style={{ position: "relative", fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 4 }}>
          carlos@lidomare.es
        </div>
        <div style={{
          position: "relative", display: "inline-flex", alignItems: "center", gap: 6, marginTop: 12,
          padding: "4px 10px", borderRadius: 999,
          background: "rgba(42,191,191,0.12)", border: "0.5px solid rgba(42,191,191,0.35)",
        }}>
          <span style={{ width: 5, height: 5, borderRadius: "50%", background: ACCENT_TURQ,
            boxShadow: `0 0 8px ${ACCENT_TURQ}` }}/>
          <span style={{ fontSize: 9, letterSpacing: "0.22em", color: ACCENT_TURQ, textTransform: "uppercase" }}>
            Miembro activo
          </span>
        </div>
      </div>

      {/* Progreso — 3 KPI */}
      <div style={{ padding: "16px 16px 0" }}>
        <Eyebrow style={{ paddingLeft: 4, marginBottom: 10 }}>Mi progreso · 30 días</Eyebrow>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
          {[
            { v: "12", u: "sesiones",  d: "+3"  },
            { v: "8.4", u: "horas",     d: "+1.2" },
            { v: "3",  u: "rachas",    d: "max" },
          ].map((k, i) => (
            <div key={i} style={{ ...glassLight(), borderRadius: 18, padding: "14px 10px", textAlign: "center",
              position: "relative", overflow: "hidden",
            }}>
              <LensSheen/>
              <div style={{
                fontSize: 32, fontWeight: 300, color: "#fff", lineHeight: 1,
                fontFamily: "'Cormorant Garamond', serif", fontFeatureSettings: "'tnum'",
                letterSpacing: "-0.02em",
              }}>{k.v}</div>
              <div style={{ fontSize: 9, letterSpacing: "0.18em", color: "rgba(255,255,255,0.4)", marginTop: 4, textTransform: "uppercase" }}>{k.u}</div>
              <div style={{ fontSize: 9, color: ACCENT_TURQ, marginTop: 4 }}>{k.d}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sparkline semanas */}
      <div style={{ padding: "16px 16px 0" }}>
        <div style={{ ...glassLight(), borderRadius: 20, padding: 16, position: "relative", overflow: "hidden" }}>
          <LensSheen/>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Eyebrow>Últimas 8 semanas</Eyebrow>
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", fontFeatureSettings: "'tnum'" }}>3 de media</span>
          </div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 8, marginTop: 14, height: 70 }}>
            {[2,3,4,2,3,4,3,3].map((v, i) => (
              <div key={i} style={{
                flex: 1, height: `${(v/5)*100}%`, borderRadius: 6,
                background: i === 7 ? `linear-gradient(180deg, ${ACCENT_TURQ}, rgba(42,191,191,0.2))` : "rgba(255,255,255,0.06)",
                border: "0.5px solid rgba(255,255,255,0.08)",
              }}/>
            ))}
          </div>
        </div>
      </div>

      {/* Settings list */}
      <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 6 }}>
        {[
          { l: "Datos personales", sub: "Nombre, email, password" },
          { l: "Notificaciones",   sub: "Recordatorios y avisos" },
          { l: "Admin",      sub: "Gestión de rutinas",       admin: true },
        ].map((r, i) => (
          <button key={i} style={{
            ...glassLight(), borderRadius: 16, padding: "14px 16px",
            display: "flex", justifyContent: "space-between", alignItems: "center",
            cursor: "pointer", border: "0.5px solid rgba(255,255,255,0.07)",
            textAlign: "left",
          }}>
            <div>
              <div style={{ fontSize: 13, color: "#fff" }}>{r.l}
                {r.admin && <span style={{
                  marginLeft: 8, fontSize: 8, letterSpacing: "0.22em", color: ACCENT_INDIGO,
                  background: "rgba(123,140,255,0.1)", border: "0.5px solid rgba(123,140,255,0.3)",
                  borderRadius: 4, padding: "2px 6px", textTransform: "uppercase",
                }}>Admin</span>}
              </div>
              <div style={{ fontSize: 10.5, color: "rgba(255,255,255,0.4)", marginTop: 2, letterSpacing: "0.02em" }}>{r.sub}</div>
            </div>
            <IconArrow c="rgba(255,255,255,0.3)"/>
          </button>
        ))}
      </div>

      {/* Sign out */}
      <div style={{ padding: "16px 16px 0" }}>
        <button onClick={onSignOut} style={{
          width: "100%", background: "rgba(255,80,80,0.05)",
          border: "0.5px solid rgba(255,80,80,0.25)", borderRadius: 16,
          padding: 14, color: "rgba(255,120,120,0.85)",
          fontSize: 10, letterSpacing: "0.22em", textTransform: "uppercase",
          cursor: "pointer", fontFamily: "inherit",
        }}>Cerrar sesión</button>
      </div>
    </div>
  );
}

Object.assign(window, { CitasV2, PerfilV2 });
