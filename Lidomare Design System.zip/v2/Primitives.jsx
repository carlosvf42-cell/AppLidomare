// Rediseño visual v2 — Lidomare App
// Shared primitives: accent, glass, icons, buttons.

const ACCENT_TURQ = "#2abfbf";
const ACCENT_INDIGO = "#7b8cff";

// ── Glass tiers ──────────────────────────────────────────────────────────
function glassHeavy(intensity = 1) {
  return {
    background: `rgba(255,255,255,${0.07 * intensity})`,
    backdropFilter: `blur(${24 * intensity}px) saturate(180%)`,
    WebkitBackdropFilter: `blur(${24 * intensity}px) saturate(180%)`,
    border: "0.5px solid rgba(255,255,255,0.13)",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.10), 0 4px 24px rgba(0,0,0,0.4)",
  };
}
function glassLight() {
  return {
    background: "rgba(255,255,255,0.03)",
    backdropFilter: "blur(12px) saturate(140%)",
    WebkitBackdropFilter: "blur(12px) saturate(140%)",
    border: "0.5px solid rgba(255,255,255,0.08)",
  };
}
// New: a "lens" card with specular highlight, inner shadow, chromatic edge
function glassLens() {
  return {
    background: "rgba(255,255,255,0.045)",
    backdropFilter: "blur(30px) saturate(200%)",
    WebkitBackdropFilter: "blur(30px) saturate(200%)",
    border: "0.5px solid rgba(255,255,255,0.14)",
    boxShadow: [
      "inset 0 1px 0 rgba(255,255,255,0.18)",
      "inset 0 -1px 0 rgba(0,0,0,0.25)",
      "inset 1px 0 0 rgba(42,191,191,0.05)",
      "inset -1px 0 0 rgba(123,140,255,0.05)",
      "0 10px 40px rgba(0,0,0,0.55)",
    ].join(", "),
  };
}

function Eyebrow({ children, color, style }) {
  return (
    <div style={{
      fontSize: 9,
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      color: color || ACCENT_TURQ,
      fontWeight: 500,
      ...style,
    }}>{children}</div>
  );
}

function MetaLabel({ children, style }) {
  return (
    <div style={{
      fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase",
      color: "rgba(255,255,255,0.35)", fontWeight: 500, ...style,
    }}>{children}</div>
  );
}

// Small specular highlight streak used on lens cards
function LensSheen({ from = "top left", angle = 150 }) {
  return (
    <div aria-hidden style={{
      position: "absolute", inset: 0, pointerEvents: "none", borderRadius: "inherit",
      background: `linear-gradient(${angle}deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 35%)`,
      mixBlendMode: "screen",
    }}/>
  );
}

// Ambient radial gradient scene for backgrounds
function Ambient({ variant = "home", showPhoto = true, photoSrc }) {
  if (variant === "home" && showPhoto && photoSrc) {
    return (
      <div aria-hidden style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0 }}>
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: `url(${photoSrc})`,
          backgroundSize: "cover", backgroundPosition: "center",
          filter: "blur(30px) saturate(120%)",
          opacity: 0.32, transform: "scale(1.15)",
        }}/>
        <div style={{ position: "absolute", inset: 0,
          background: "linear-gradient(180deg, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.88) 55%, #000 100%)" }}/>
        <div style={{ position: "absolute", top: "-5%", right: "-15%", width: "65%", height: "55%", borderRadius: "50%",
          background: "radial-gradient(circle, rgba(42,191,191,0.22) 0%, transparent 65%)", filter: "blur(60px)" }}/>
        <div style={{ position: "absolute", top: "45%", left: "-20%", width: "55%", height: "45%", borderRadius: "50%",
          background: "radial-gradient(circle, rgba(123,140,255,0.13) 0%, transparent 65%)", filter: "blur(80px)" }}/>
      </div>
    );
  }
  return (
    <div aria-hidden style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0 }}>
      <div style={{ position: "absolute", inset: 0, background: "#020407" }}/>
      <div style={{ position: "absolute", top: "-10%", right: "-20%", width: "75%", height: "60%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(42,191,191,0.26) 0%, transparent 65%)", filter: "blur(70px)" }}/>
      <div style={{ position: "absolute", top: "30%", left: "-25%", width: "65%", height: "55%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(123,140,255,0.18) 0%, transparent 65%)", filter: "blur(90px)" }}/>
      <div style={{ position: "absolute", bottom: "0%", right: "10%", width: "55%", height: "40%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(42,191,191,0.14) 0%, transparent 65%)", filter: "blur(80px)" }}/>
    </div>
  );
}

// ── Icons (22×22, 1.4 stroke)  ───────────────────────────────────────────
function IconHome({ active })   { const c = active ? ACCENT_TURQ : "rgba(255,255,255,0.35)"; return (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1H15v-5H9v5H4a1 1 0 01-1-1V10.5z" stroke={c} strokeWidth="1.4" strokeLinejoin="round"/></svg>);}
function IconGrid({ active })   { const c = active ? ACCENT_TURQ : "rgba(255,255,255,0.35)"; return (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" stroke={c} strokeWidth="1.4"/>
    <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" stroke={c} strokeWidth="1.4"/>
    <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" stroke={c} strokeWidth="1.4"/>
    <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" stroke={c} strokeWidth="1.4"/>
  </svg>);}
function IconCal({ active })    { const c = active ? ACCENT_TURQ : "rgba(255,255,255,0.35)"; return (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <rect x="3" y="5" width="18" height="16" rx="2" stroke={c} strokeWidth="1.4"/>
    <path d="M3 10h18M8 3v4M16 3v4" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>);}
function IconUser({ active })   { const c = active ? ACCENT_TURQ : "rgba(255,255,255,0.35)"; return (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="8" r="4" stroke={c} strokeWidth="1.4"/>
    <path d="M4 20c0-3.314 3.582-6 8-6s8 2.686 8 6" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>);}
function IconPlay({ c = "#000", size = 18 }) { return (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={c}><path d="M8 5v14l11-7z"/></svg>);}
function IconArrow({ c = ACCENT_TURQ, size = 14 }) { return (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 5l7 7-7 7" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>);}
function IconCheck({ c = ACCENT_TURQ, size = 10 }) { return (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M5 12l5 5L19 7" stroke={c} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>);}
function IconFlame() { return (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <path d="M12 2s4 4.5 4 9a4 4 0 01-8 0c0-2 1-3 1-5-2 1-5 4-5 8a8 8 0 0016 0c0-6-8-12-8-12z" stroke={ACCENT_TURQ} strokeWidth="1.3" strokeLinejoin="round"/>
  </svg>);}
function IconLock({ c = ACCENT_TURQ, size = 11 }) { return (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <rect x="5" y="10" width="14" height="10" rx="2" stroke={c} strokeWidth="1.4"/>
    <path d="M8 10V7a4 4 0 018 0v3" stroke={c} strokeWidth="1.4"/>
  </svg>);}
function IconBolt() { return (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" stroke={ACCENT_TURQ} strokeWidth="1.3" strokeLinejoin="round"/></svg>);}

// Primary button: solid turquoise on dark
function PrimaryBtn({ children, onClick, icon, style }) {
  return (
    <button onClick={onClick} style={{
      background: `linear-gradient(180deg, ${ACCENT_TURQ} 0%, #1f9e9e 100%)`,
      color: "#001a1a",
      fontSize: 11, fontWeight: 700, letterSpacing: "0.22em", textTransform: "uppercase",
      padding: 16, border: "none", borderRadius: 16, width: "100%",
      boxShadow: "0 8px 32px rgba(42,191,191,0.32), inset 0 1px 0 rgba(255,255,255,0.35), inset 0 -1px 0 rgba(0,0,0,0.15)",
      display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
      cursor: "pointer", transition: "transform 0.1s ease",
      ...style,
    }}
    onMouseDown={e => e.currentTarget.style.transform = "scale(0.98)"}
    onMouseUp={e => e.currentTarget.style.transform = "scale(1)"}
    onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}>
      {icon} {children}
    </button>
  );
}

function GhostBtn({ children, onClick, style }) {
  return (
    <button onClick={onClick} style={{
      background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.85)",
      fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase",
      padding: 16, border: "0.5px solid rgba(255,255,255,0.18)", borderRadius: 14,
      width: "100%", cursor: "pointer", ...style,
    }}>{children}</button>
  );
}

Object.assign(window, {
  ACCENT_TURQ, ACCENT_INDIGO,
  glassHeavy, glassLight, glassLens,
  Eyebrow, MetaLabel, LensSheen, Ambient,
  IconHome, IconGrid, IconCal, IconUser, IconPlay, IconArrow, IconCheck, IconFlame, IconLock, IconBolt,
  PrimaryBtn, GhostBtn,
});
