function SesionV2({ go }) {
  // Ejercicio actual (mock)
  const exercises = [
    { name: "Press banca", sets: 4, reps: 8, done: 1 },
    { name: "Press militar", sets: 4, reps: 10, done: 0 },
    { name: "Fondos en paralelas", sets: 3, reps: 12, done: 0 },
    { name: "Elevaciones laterales", sets: 3, reps: 15, done: 0 },
  ];
  const currentIdx = 0;
  const current = exercises[currentIdx];
  const currentSet = 2; // segunda serie
  const [reps, setReps] = React.useState(8);
  const [peso, setPeso] = React.useState(60);
  const [resting, setResting] = React.useState(false);
  const [restSec, setRestSec] = React.useState(90);

  React.useEffect(() => {
    if (!resting) return;
    if (restSec <= 0) { setResting(false); setRestSec(90); return; }
    const t = setTimeout(() => setRestSec(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resting, restSec]);

  const totalSessionMin = 18;

  return (
    <div style={{ paddingBottom: 20 }}>
      {/* Top bar: close + progress */}
      <div style={{ position: "sticky", top: 0, zIndex: 20,
        padding: "56px 20px 14px",
        background: "linear-gradient(to bottom, #000 0%, #000 70%, transparent 100%)",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <button onClick={() => go("home")} style={{
            width: 40, height: 40, borderRadius: "50%", ...glassLight(),
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "0.5px solid rgba(255,255,255,0.1)", cursor: "pointer",
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M6 6l12 12M18 6L6 18" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
          <div style={{ textAlign: "center" }}>
            <Eyebrow>Sesión en curso</Eyebrow>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 4, fontFeatureSettings: "'tnum'" }}>
              {totalSessionMin}:42 · Día 2 · Empuje
            </div>
          </div>
          <button style={{
            width: 40, height: 40, borderRadius: "50%", ...glassLight(),
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "0.5px solid rgba(255,255,255,0.1)", cursor: "pointer",
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="5" r="1.4" fill="rgba(255,255,255,0.7)"/>
              <circle cx="12" cy="12" r="1.4" fill="rgba(255,255,255,0.7)"/>
              <circle cx="12" cy="19" r="1.4" fill="rgba(255,255,255,0.7)"/>
            </svg>
          </button>
        </div>

        {/* Session progress bar — segmented by exercise */}
        <div style={{ display: "flex", gap: 4 }}>
          {exercises.map((ex, i) => (
            <div key={i} style={{
              flex: ex.sets,
              height: 3, borderRadius: 2, overflow: "hidden",
              background: "rgba(255,255,255,0.08)",
            }}>
              <div style={{
                width: i < currentIdx ? "100%" : i === currentIdx ? `${(currentSet / ex.sets) * 100}%` : "0%",
                height: "100%", background: `linear-gradient(90deg, ${ACCENT_TURQ}, ${ACCENT_INDIGO})`,
                transition: "width 0.4s ease",
              }}/>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 16 }}>

        {/* Current exercise — big lens card */}
        <div style={{ position: "relative", borderRadius: 32, overflow: "hidden",
          minHeight: 340, ...glassLens(),
        }}>
          <LensSheen angle={135}/>
          {/* color blobs */}
          <div aria-hidden style={{
            position: "absolute", top: -60, right: -40, width: 200, height: 200, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(42,191,191,0.38) 0%, transparent 70%)",
            filter: "blur(30px)",
          }}/>
          <div aria-hidden style={{
            position: "absolute", bottom: -40, left: -40, width: 180, height: 180, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(123,140,255,0.28) 0%, transparent 70%)",
            filter: "blur(30px)",
          }}/>

          {/* Exercise label */}
          <div style={{ position: "relative", zIndex: 1, padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Eyebrow style={{ whiteSpace: "nowrap" }}>Ejercicio {currentIdx + 1} / {exercises.length}</Eyebrow>
              <button style={{
                background: "rgba(0,0,0,0.25)", border: "0.5px solid rgba(255,255,255,0.1)",
                borderRadius: 999, padding: "4px 10px",
                fontSize: 9, letterSpacing: "0.18em", color: ACCENT_TURQ, textTransform: "uppercase",
                cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
              }}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7z" fill={ACCENT_TURQ}/></svg>
                Ver vídeo
              </button>
            </div>
            <div style={{
              fontSize: 40, fontWeight: 300, color: "#fff", marginTop: 14,
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              lineHeight: 1, letterSpacing: "-0.01em",
            }}>{current.name}</div>

            {/* Big set counter */}
            <div style={{ marginTop: 28, display: "flex", alignItems: "baseline", gap: 14 }}>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                Serie
              </div>
              <div style={{ fontSize: 96, fontWeight: 200, color: "#fff", lineHeight: 0.85,
                fontFamily: "'Cormorant Garamond', serif", letterSpacing: "-0.04em",
                fontFeatureSettings: "'tnum'", display: "flex", alignItems: "baseline",
              }}>
                {currentSet}
                <span style={{ fontSize: 28, color: "rgba(255,255,255,0.3)", margin: "0 8px" }}>/</span>
                <span style={{ fontSize: 36, color: "rgba(255,255,255,0.4)" }}>{current.sets}</span>
              </div>
            </div>

            {/* Set pills — horizontal */}
            <div style={{ display: "flex", gap: 6, marginTop: 16 }}>
              {Array.from({length: current.sets}, (_, i) => {
                const isDone = i < current.done;
                const isCurrent = i === currentSet - 1;
                return (
                  <div key={i} style={{
                    flex: 1, padding: "6px 4px", borderRadius: 10, textAlign: "center",
                    background: isDone ? "rgba(42,191,191,0.18)"
                              : isCurrent ? "rgba(42,191,191,0.05)" : "rgba(255,255,255,0.02)",
                    border: isDone ? "0.5px solid rgba(42,191,191,0.5)"
                          : isCurrent ? "0.5px solid rgba(42,191,191,0.5)"
                          : "0.5px solid rgba(255,255,255,0.06)",
                    fontSize: 10, color: isDone ? ACCENT_TURQ : isCurrent ? "#fff" : "rgba(255,255,255,0.25)",
                    letterSpacing: "0.05em",
                    fontFeatureSettings: "'tnum'",
                  }}>S{i+1}</div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Reps + weight control — dual steppers */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Stepper label="Repeticiones" value={reps} setValue={setReps} unit={`obj ${current.reps}`} step={1}/>
          <Stepper label="Peso" value={peso} setValue={setPeso} unit="kg" step={2.5} decimals/>
        </div>

        {/* Primary + rest action */}
        {!resting ? (
          <>
            <PrimaryBtn icon={<IconCheck c="#001a1a" size={12}/>} onClick={() => setResting(true)}>
              Completar serie
            </PrimaryBtn>
            <button onClick={() => setResting(true)} style={{
              background: "rgba(42,191,191,0.06)",
              border: "0.5px solid rgba(42,191,191,0.22)",
              color: ACCENT_TURQ, borderRadius: 14, padding: 14,
              fontSize: 10, letterSpacing: "0.22em", textTransform: "uppercase",
              cursor: "pointer",
            }}>Descanso · 1:30</button>
          </>
        ) : (
          <RestCard sec={restSec} totalSec={90} onSkip={() => { setResting(false); setRestSec(90); }}/>
        )}

        {/* Next up */}
        <div style={{ borderRadius: 20, padding: "14px 16px", ...glassLight() }}>
          <div style={{ fontSize: 8, letterSpacing: "0.22em", color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>
            Siguiente
          </div>
          <div style={{ marginTop: 6, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 16, fontWeight: 400, color: "#fff" }}>
              {exercises[currentIdx + 1].name}
            </div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", fontFeatureSettings: "'tnum'" }}>
              {exercises[currentIdx + 1].sets} × {exercises[currentIdx + 1].reps}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stepper({ label, value, setValue, unit, step = 1, decimals = false }) {
  const fmt = (v) => decimals ? (Math.round(v * 10) / 10).toString() : v.toString();
  return (
    <div style={{ ...glassLight(), borderRadius: 20, padding: "14px 16px", position: "relative", overflow: "hidden" }}>
      <LensSheen/>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 8.5, letterSpacing: "0.22em", color: "rgba(255,255,255,0.4)", textTransform: "uppercase" }}>{label}</span>
        <span style={{ fontSize: 9, color: ACCENT_TURQ, letterSpacing: "0.1em" }}>{unit}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
        <button onClick={() => setValue(Math.max(0, value - step))} style={stepBtnStyle}>−</button>
        <div style={{
          fontSize: 38, fontWeight: 300, color: "#fff", lineHeight: 1,
          fontFamily: "'Cormorant Garamond', serif", fontFeatureSettings: "'tnum'",
          letterSpacing: "-0.02em",
        }}>{fmt(value)}</div>
        <button onClick={() => setValue(value + step)} style={stepBtnStyle}>+</button>
      </div>
    </div>
  );
}

const stepBtnStyle = {
  width: 34, height: 34, borderRadius: 10,
  background: "rgba(255,255,255,0.04)",
  border: "0.5px solid rgba(255,255,255,0.12)",
  color: "rgba(255,255,255,0.8)", fontSize: 18, fontWeight: 300,
  cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
};

function RestCard({ sec, totalSec, onSkip }) {
  const pct = 1 - sec / totalSec;
  const R = 42;
  const C = 2 * Math.PI * R;
  return (
    <div style={{
      position: "relative", borderRadius: 24, padding: "20px 20px", ...glassLens(),
      display: "flex", alignItems: "center", gap: 18, overflow: "hidden",
    }}>
      <LensSheen/>
      <div aria-hidden style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(circle at 80% 50%, rgba(42,191,191,0.18), transparent 60%)",
      }}/>
      <div style={{ position: "relative", width: 100, height: 100, flexShrink: 0 }}>
        <svg width="100" height="100" viewBox="0 0 100 100" style={{ transform: "rotate(-90deg)" }}>
          <circle cx="50" cy="50" r={R} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3"/>
          <circle cx="50" cy="50" r={R} fill="none" stroke={ACCENT_TURQ} strokeWidth="3"
            strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - pct)}
            style={{ transition: "stroke-dashoffset 1s linear" }}/>
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <div style={{ fontSize: 32, fontWeight: 300, color: "#fff",
            fontFamily: "'Cormorant Garamond', serif", lineHeight: 1,
            fontFeatureSettings: "'tnum'" }}>0:{sec.toString().padStart(2, "0")}</div>
          <div style={{ fontSize: 8, letterSpacing: "0.22em", color: ACCENT_TURQ, textTransform: "uppercase", marginTop: 2 }}>Descanso</div>
        </div>
      </div>
      <div style={{ position: "relative", flex: 1 }}>
        <Eyebrow>Recupera</Eyebrow>
        <div style={{ fontSize: 16, color: "#fff", marginTop: 4, lineHeight: 1.35 }}>
          Respira profundo y prepara la siguiente serie.
        </div>
        <button onClick={onSkip} style={{
          marginTop: 12, background: "none", border: "0.5px solid rgba(255,255,255,0.2)",
          borderRadius: 10, padding: "8px 14px", color: "rgba(255,255,255,0.75)",
          fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase",
          cursor: "pointer",
        }}>Saltar →</button>
      </div>
    </div>
  );
}

Object.assign(window, { SesionV2 });
