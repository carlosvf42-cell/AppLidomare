// Shell v2 — 430px phone frame + ambient bg + glass bottom nav with floating capsule indicator.

function BottomNavV2({ route, go }) {
  const tabs = [
    { id: "home",      label: "home",      Icon: IconHome },
    { id: "contenido", label: "contenido", Icon: IconGrid },
    { id: "citas",     label: "citas",     Icon: IconCal  },
    { id: "perfil",    label: "perfil",    Icon: IconUser },
  ];
  const activeIdx = tabs.findIndex(t => t.id === route);
  return (
    <nav style={{
      position: "absolute", left: 12, right: 12, bottom: 12, zIndex: 50,
      height: 64, borderRadius: 28,
      display: "flex", alignItems: "center",
      ...glassLens(),
      overflow: "hidden",
    }}>
      <LensSheen />
      {/* Floating capsule behind active tab */}
      <div aria-hidden style={{
        position: "absolute",
        top: 8, bottom: 8,
        left: `calc(${(activeIdx / tabs.length) * 100}% + 6px)`,
        width: `calc(${100 / tabs.length}% - 12px)`,
        borderRadius: 22,
        background: "rgba(42,191,191,0.10)",
        border: "0.5px solid rgba(42,191,191,0.30)",
        boxShadow: "inset 0 1px 0 rgba(255,255,255,0.12), 0 4px 18px rgba(42,191,191,0.18)",
        transition: "left 0.38s cubic-bezier(0.4, 0.0, 0.2, 1)",
      }}/>
      {tabs.map((t, i) => {
        const active = i === activeIdx;
        return (
          <button key={t.id} onClick={() => go(t.id)} style={{
            position: "relative", zIndex: 1, flex: 1, background: "none", border: "none",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            gap: 3, padding: 0, cursor: "pointer", color: active ? ACCENT_TURQ : "rgba(255,255,255,0.35)",
            fontFamily: "inherit",
          }}>
            <t.Icon active={active}/>
            <span style={{ fontSize: 8.5, letterSpacing: "0.18em", textTransform: "uppercase" }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function Shell({ route, go, children, showNav = true, ambient = "home", showPhoto = true, photoSrc }) {
  return (
    <div style={{
      width: 430, height: 860, position: "relative", background: "#000",
      overflow: "hidden", borderRadius: 48, border: "0.5px solid #1a1a1a",
      boxShadow: "0 30px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.03)",
      fontFamily: "'Inter', -apple-system, 'SF Pro Text', system-ui, sans-serif",
      color: "rgba(255,255,255,0.92)",
    }}>
      <Ambient variant={ambient} showPhoto={showPhoto} photoSrc={photoSrc}/>
      {/* Status bar */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 44, zIndex: 10,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "14px 28px 0", color: "rgba(255,255,255,0.9)",
        fontSize: 14, fontWeight: 600, fontFeatureSettings: "'tnum'",
        pointerEvents: "none",
      }}>
        <span>9:41</span>
        <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
          <svg width="16" height="10" viewBox="0 0 18 12"><rect x="0" y="3" width="3" height="6" rx="1" fill="#fff"/><rect x="5" y="1.5" width="3" height="9" rx="1" fill="#fff"/><rect x="10" y="0" width="3" height="12" rx="1" fill="#fff" opacity="0.35"/><rect x="15" y="0" width="3" height="12" rx="1" fill="#fff" opacity="0.35"/></svg>
          <svg width="24" height="10" viewBox="0 0 28 12"><rect x="0" y="0" width="24" height="12" rx="3" stroke="#fff" strokeOpacity="0.5" fill="none"/><rect x="2" y="2" width="17" height="8" rx="1.5" fill="#fff"/><rect x="25" y="4" width="2" height="4" rx="0.5" fill="#fff" opacity="0.5"/></svg>
        </div>
      </div>
      <div style={{
        position: "absolute", inset: 0, zIndex: 1, overflowY: "auto",
        paddingBottom: showNav ? 96 : 0,
      }}>
        {children}
      </div>
      {showNav && <BottomNavV2 route={route} go={go} />}
    </div>
  );
}

Object.assign(window, { Shell });
