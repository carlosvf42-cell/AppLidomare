function ContenidoScreen({ onOpen }) {
  const sections = [
    { id: "rutina", cat: "Entrenamiento", t: "Mi Rutina", s: "Tu plan de entrenamiento personalizado" },
    { id: "ejercicio", cat: "Ejercicio", t: "Ejercicio Terapéutico", s: "Protocolos de rehabilitación" },
    { id: "activacion", cat: "Activación", t: "Activación y Movilidad", s: "Calentamiento y preparación" },
    { id: "webinars", cat: "Webinar", t: "Webinars", s: "Sesiones formativas en directo", locked: true },
  ];
  return (
    <div>
      <div style={{ padding: "56px 20px 20px" }}>
        <p style={{ fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase",
          color: "rgba(255,255,255,0.3)", marginBottom: 4, margin: 0 }}>biblioteca</p>
        <h1 style={{ fontSize: 24, fontWeight: 300, letterSpacing: "-0.01em",
          color: "rgba(255,255,255,0.92)", margin: "4px 0 0" }}>Contenido</h1>
      </div>
      <div style={{ padding: "0 16px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
        {sections.map(s => (
          <button key={s.id} onClick={() => !s.locked && onOpen(s.id)} style={{
            position: "relative", textAlign: "left",
            background: "rgba(255,255,255,0.03)", border: "0.5px solid rgba(255,255,255,0.08)",
            borderRadius: 20, backdropFilter: "blur(10px)", padding: 20,
            display: "flex", flexDirection: "column", gap: 8, minHeight: 110,
            opacity: s.locked ? 0.5 : 1, cursor: s.locked ? "default" : "pointer",
          }}>
            {s.locked && (
              <div style={{ position: "absolute", top: 12, right: 12,
                background: "rgba(42,191,191,0.1)", border: "0.5px solid #2abfbf",
                color: "#2abfbf", fontSize: 9, letterSpacing: "0.2em",
                borderRadius: 6, padding: "4px 10px", textTransform: "uppercase" }}>Próximamente</div>
            )}
            <div style={{ fontSize: 9, letterSpacing: "0.2em", color: "#2abfbf", textTransform: "uppercase" }}>{s.cat}</div>
            <div style={{ fontSize: 18, fontWeight: 600, color: "#f0f0f0", letterSpacing: "0.05em" }}>{s.t}</div>
            <div style={{ fontSize: 12, color: "#444", lineHeight: 1.5 }}>{s.s}</div>
            <div style={{ fontSize: 10, color: "#2abfbf", marginTop: "auto", letterSpacing: "0.1em" }}>VER →</div>
          </button>
        ))}
      </div>
    </div>
  );
}

function CitasScreen() {
  const card = (eyebrow, big, hint, accentPos) => (
    <div style={{ height: "35vh", minHeight: 240, borderRadius: 20,
      border: "0.5px solid rgba(255,255,255,0.08)", backdropFilter: "blur(10px)",
      position: "relative", overflow: "hidden", display: "flex", flexDirection: "column",
      justifyContent: "flex-end", padding: "28px 24px", background: "#0a0a0a", cursor: "pointer" }}>
      <div style={{ position: "absolute", inset: 0,
        background: `radial-gradient(circle at ${accentPos} 50%, rgba(42,191,191,0.08) 0%, transparent 60%)`,
        pointerEvents: "none" }}/>
      <div style={{ fontSize: 9, letterSpacing: "0.2em", color: "#2abfbf", textTransform: "uppercase", marginBottom: 8 }}>{eyebrow}</div>
      <div style={{ fontSize: 36, fontWeight: 800, color: "#f0f0f0", lineHeight: 1,
        textTransform: "uppercase", fontFamily: "'Barlow Condensed', sans-serif" }}>{big}</div>
      <div style={{ fontSize: 12, color: "#333", marginTop: 10 }}>{hint}</div>
    </div>
  );
  return (
    <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12, paddingTop: 48 }}>
      {card("Salonized", <>Reservar<br/>cita</>, "Gestiona tus reservas online →", "30%")}
      {card("WhatsApp", <>Asesoramiento<br/>personal</>, "Contacta con tu entrenador →", "70%")}
    </div>
  );
}

function PerfilScreen({ onSignOut }) {
  return (
    <div style={{ paddingTop: 56, paddingBottom: 80 }}>
      <p style={{ fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase",
        padding: "0 24px", marginBottom: 32, color: "#2abfbf" }}>Perfil</p>

      <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 24, padding: "0 20px" }}>
        <div style={{ width: 64, height: 64, borderRadius: "50%",
          background: "rgba(42,191,191,0.12)", backdropFilter: "blur(20px)",
          border: "0.5px solid rgba(42,191,191,0.3)", color: "#2abfbf",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 18, fontWeight: 300, boxShadow: "inset 0 1px 0 rgba(255,255,255,0.1)" }}>CA</div>
        <div style={{ minWidth: 0 }}>
          <p style={{ fontSize: 14, fontWeight: 300, color: "rgba(255,255,255,0.9)", margin: 0 }}>carlos@lidomare.es</p>
          <p style={{ fontSize: 12, fontWeight: 300, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>Miembro activo</p>
        </div>
      </div>

      <div style={{ ...GLASS, borderRadius: 16, margin: "0 16px 12px" }}>
        <div style={{ padding: "14px 20px" }}>
          <p style={{ fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase",
            color: "rgba(255,255,255,0.3)", marginBottom: 4, margin: 0 }}>Email</p>
          <p style={{ fontSize: 14, fontWeight: 300, color: "rgba(255,255,255,0.85)", marginTop: 4 }}>carlos@lidomare.es</p>
        </div>
      </div>

      <button onClick={onSignOut} style={{
        width: "calc(100% - 32px)", margin: "0 16px 20px",
        ...GLASS, borderRadius: 16, padding: 14,
        fontSize: 12, letterSpacing: "0.15em", textTransform: "uppercase",
        color: "rgba(255,100,100,0.7)", border: "0.5px solid rgba(255,80,80,0.2)",
        cursor: "pointer",
      }}>Cerrar sesión</button>

      <div style={{ margin: "8px 16px", height: "0.5px", background: "rgba(255,255,255,0.07)" }} />

      <div style={{ padding: "16px 20px" }}>
        <p style={{ fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase",
          color: "rgba(255,255,255,0.3)", marginBottom: 12, margin: 0 }}>Mi progreso</p>
        <div style={{ ...GLASS, borderRadius: 16, padding: "16px 20px", marginTop: 12 }}>
          <div style={{ fontSize: 9, letterSpacing: "0.2em", color: "#2abfbf", textTransform: "uppercase" }}>Últimos 30 días</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: "#f0f0f0", marginTop: 4 }}>12 sesiones</div>
          <div style={{ fontSize: 11, color: "#444", marginTop: 2 }}>+3 vs. mes anterior</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ContenidoScreen, CitasScreen, PerfilScreen });
