function HomeScreen({ sessions, onTrain }) {
  const labels = ["L","M","X","J","V","S","D"];
  const days = [
    { n: 14, done: true }, { n: 15, done: true }, { n: 16, started: true, today: true },
    { n: 17 }, { n: 18 }, { n: 19 }, { n: 20 },
  ];
  return (
    <div>
      {/* Hero */}
      <div style={{ position: "relative", overflow: "hidden", height: 280 }}>
        <div style={{ position: "absolute", inset: 0,
          background: "linear-gradient(135deg, #1a2e2e 0%, #0a1a1f 60%, #000 100%)",
        }} aria-hidden />
        <div style={{ position: "absolute", inset: 0,
          background: "radial-gradient(circle at 70% 30%, rgba(42,191,191,0.25) 0%, transparent 50%)",
        }} aria-hidden />
        <div style={{ position: "absolute", inset: 0,
          background: "linear-gradient(to bottom, transparent 30%, rgba(0,0,0,0.9) 100%)" }} aria-hidden />
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "0 20px 24px" }}>
          <h1 style={{ fontSize: "2rem", fontWeight: 300, lineHeight: 1.1, letterSpacing: "-0.01em",
            color: "rgba(255,255,255,0.95)", margin: 0 }}>Lidomare Health App</h1>
          <p style={{ fontSize: 9, color: "#2abfbf", letterSpacing: "0.2em", textTransform: "uppercase", marginTop: 4 }}>
            Powered by Antifrágil®
          </p>
        </div>
      </div>

      <div style={{ padding: "20px 16px 24px", display: "flex", flexDirection: "column", gap: 20 }}>
        <div style={{ padding: "0 4px" }}>
          <p style={{ fontSize: 10, color: "#555", letterSpacing: "0.2em", textTransform: "uppercase", margin: 0 }}>Bienvenido de nuevo</p>
          <p style={{ fontSize: 30, fontWeight: 700, color: "#f0f0f0", lineHeight: 1.1, marginTop: 2, margin: 0 }}>Carlos</p>
          <p style={{ fontSize: 12, color: "#333", marginTop: 4 }}>Miércoles, 16 de abril</p>
        </div>

        {/* Week calendar */}
        <div style={{ ...GLASS, borderRadius: 28, padding: "16px 16px" }}>
          <Eyebrow style={{ marginBottom: 12 }}>Semana actual</Eyebrow>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            {days.map((d, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 12, fontWeight: 300,
                  background: d.done ? "rgba(42,191,191,0.2)" : d.started ? "rgba(42,191,191,0.07)" : "rgba(255,255,255,0.04)",
                  border: d.done ? "1.5px solid rgba(42,191,191,0.6)" : d.today ? "1.5px solid rgba(42,191,191,0.45)" : "1px solid rgba(255,255,255,0.08)",
                  color: d.done ? "#2abfbf" : d.today ? "rgba(42,191,191,0.8)" : "rgba(255,255,255,0.3)",
                }}>{d.n}</div>
                <span style={{ fontSize: 8, color: "rgba(255,255,255,0.2)" }}>{labels[i]}</span>
                <div style={{ height: 10 }}>{d.done && (
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
                    <path d="M5 12l5 5L19 7" stroke="#2abfbf" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Streak */}
        <div style={{
          background: "rgba(255,255,255,0.03)", border: "0.5px solid rgba(255,255,255,0.08)",
          borderRadius: 16, padding: "16px 20px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          backdropFilter: "blur(10px)", WebkitBackdropFilter: "blur(10px)",
        }}>
          <div>
            <div style={{ fontSize: 9, letterSpacing: "0.2em", color: "#555", textTransform: "uppercase" }}>Racha actual</div>
            <div style={{ fontSize: 28, fontWeight: 700, color: "#f0f0f0", marginTop: 4 }}>3 semanas</div>
            <div style={{ fontSize: 11, color: "#2abfbf", marginTop: 2 }}>Muy bien, sigue así</div>
          </div>
          <div style={{ position: "relative", width: 64, height: 64 }}>
            <svg width="64" height="64" viewBox="0 0 64 64" style={{ transform: "rotate(-90deg)" }}>
              <circle cx="32" cy="32" r="26" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="5"/>
              <circle cx="32" cy="32" r="26" fill="none" stroke="#2abfbf" strokeWidth="5"
                strokeLinecap="round" strokeDasharray={2*Math.PI*26} strokeDashoffset={2*Math.PI*26*(1-3/8)}/>
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column",
              alignItems: "center", justifyContent: "center" }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#f0f0f0", lineHeight: 1 }}>3</div>
              <div style={{ fontSize: 7, color: "#2abfbf", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 1 }}>sem</div>
            </div>
          </div>
        </div>

        {/* Próximo entrenamiento */}
        <div>
          <div style={{ fontSize: 9, letterSpacing: "0.2em", color: "#555", textTransform: "uppercase", marginBottom: 10 }}>
            Próximo entrenamiento
          </div>
          <div style={{ background: "rgba(255,255,255,0.03)", border: "0.5px solid rgba(255,255,255,0.08)",
            borderRadius: 16, padding: "16px 20px", marginBottom: 12 }}>
            <div style={{ fontSize: 9, color: "#2abfbf", letterSpacing: "0.2em", textTransform: "uppercase" }}>Full body · Intermedio</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: "#f0f0f0", marginTop: 4 }}>Día 2 · Empuje</div>
            <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 4 }}>
              {[
                ["Press banca", "4×8"],
                ["Press militar", "4×10"],
                ["Fondos", "3×12"],
                ["Elevaciones laterales", "3×15"],
              ].map(([n, s], i) => (
                <div key={i} style={{ fontSize: 11, color: "#444", display: "flex", justifyContent: "space-between" }}>
                  <span>{n}</span><span style={{ color: "#2a2a2a" }}>{s}</span>
                </div>
              ))}
            </div>
          </div>
          <button onClick={onTrain} style={{
            display: "block", width: "100%", padding: 16,
            background: "rgba(255,255,255,0.04)", border: "0.5px solid rgba(255,255,255,0.2)",
            borderRadius: 6, color: "#f0f0f0", fontSize: 10,
            letterSpacing: "0.25em", textTransform: "uppercase", cursor: "pointer",
          }}>Entrenar ahora →</button>
        </div>

        <p style={{ textAlign: "center", paddingTop: 8, fontSize: 10,
          color: "rgba(255,255,255,0.12)", letterSpacing: "0.1em", margin: 0 }}>
          © 2026 Lidomare · Playamar, Torremolinos
        </p>
      </div>
    </div>
  );
}
Object.assign(window, { HomeScreen });
