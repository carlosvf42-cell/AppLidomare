// 430px shell with ambient glass background + bottom nav.

function AmbientBg() {
  return (
    <div aria-hidden style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0 }}>
      <div style={{ position: "absolute", top: "-5%", right: "-15%", width: "65%", height: "55%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(42,191,191,0.28) 0%, transparent 65%)", filter: "blur(70px)" }} />
      <div style={{ position: "absolute", top: "25%", left: "-20%", width: "55%", height: "55%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(99,102,241,0.22) 0%, transparent 65%)", filter: "blur(90px)" }} />
      <div style={{ position: "absolute", bottom: "5%", right: "15%", width: "50%", height: "40%", borderRadius: "50%",
        background: "radial-gradient(circle, rgba(42,191,191,0.15) 0%, transparent 65%)", filter: "blur(80px)" }} />
    </div>
  );
}

function BottomNav({ route, go }) {
  const tabs = [
    { id: "home", label: "home", d: "M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1H15v-5H9v5H4a1 1 0 01-1-1V10.5z" },
    { id: "contenido", label: "contenido", custom: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
        <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
        <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
        <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
      </svg>
    ) },
    { id: "citas", label: "citas", custom: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="5" width="18" height="16" rx="2" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
        <path d="M3 10h18M8 3v4M16 3v4" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    ) },
    { id: "perfil", label: "perfil", custom: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="8" r="4" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4"/>
        <path d="M4 20c0-3.314 3.582-6 8-6s8 2.686 8 6" stroke={active ? TURQ : "rgba(255,255,255,0.35)"} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    ) },
  ];
  return (
    <nav style={{
      position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 50,
      background: "rgba(0,0,0,0.55)",
      backdropFilter: "blur(40px) saturate(180%)",
      WebkitBackdropFilter: "blur(40px) saturate(180%)",
      borderTop: "0.5px solid rgba(255,255,255,0.15)",
      display: "flex",
      paddingBottom: 6,
    }}>
      {tabs.map(t => {
        const active = route === t.id;
        return (
          <button key={t.id} onClick={() => go(t.id)} style={{
            flex: 1, background: "none", border: "none", color: active ? TURQ : "rgba(255,255,255,0.35)",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            padding: "12px 0 6px", cursor: "pointer", gap: 3, minHeight: 56,
          }}>
            {t.custom ? t.custom(active) : <Ic d={t.d} active={active} />}
            <span style={{ fontSize: 9, letterSpacing: "0.06em" }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function Shell({ route, go, children, showNav = true }) {
  return (
    <div style={{
      width: 430, height: 812, position: "relative", background: "#000",
      overflow: "hidden", borderRadius: 48, border: "0.5px solid #1a1a1a",
      boxShadow: "0 30px 80px rgba(0,0,0,0.7)",
      fontFamily: "'Inter', -apple-system, 'SF Pro Text', system-ui, sans-serif",
      color: "rgba(255,255,255,0.92)",
    }}>
      <AmbientBg />
      <div style={{
        position: "absolute", inset: 0, zIndex: 1, overflowY: "auto",
        paddingBottom: showNav ? 70 : 0,
      }}>
        {children}
      </div>
      {showNav && <BottomNav route={route} go={go} />}
    </div>
  );
}

Object.assign(window, { Shell });
