// Shared primitives for the Lidomare UI kit.
// Pure-cosmetic; no real data.

const TURQ = "#2abfbf";

const GLASS = {
  background: "rgba(255,255,255,0.07)",
  backdropFilter: "blur(24px) saturate(180%)",
  WebkitBackdropFilter: "blur(24px) saturate(180%)",
  border: "0.5px solid rgba(255,255,255,0.13)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.10), 0 4px 24px rgba(0,0,0,0.4)",
};

const GLASS_SM = {
  background: "rgba(255,255,255,0.03)",
  backdropFilter: "blur(10px)",
  WebkitBackdropFilter: "blur(10px)",
  border: "0.5px solid rgba(255,255,255,0.08)",
  borderRadius: 12,
};

function Eyebrow({ children, dim, style }) {
  return (
    <div style={{
      fontSize: dim ? 10 : 9,
      letterSpacing: dim ? "0.25em" : "0.22em",
      textTransform: "uppercase",
      color: dim ? "rgba(255,255,255,0.30)" : TURQ,
      fontWeight: 500,
      ...style,
    }}>{children}</div>
  );
}

function Chip({ children, variant = "default" }) {
  const v = {
    accent:  { bg: "rgba(42,191,191,0.12)", color: TURQ, brd: "rgba(42,191,191,0.25)" },
    locked:  { bg: "rgba(42,191,191,0.10)", color: TURQ, brd: TURQ },
    default: { bg: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)", brd: "rgba(255,255,255,0.1)" },
  }[variant];
  return (
    <span style={{
      background: v.bg, color: v.color,
      border: `0.5px solid ${v.brd}`,
      fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase",
      borderRadius: 9999, padding: "4px 10px",
    }}>{children}</span>
  );
}

function PrimaryButton({ children, onClick, icon, style }) {
  return (
    <button onClick={onClick} style={{
      background: TURQ, color: "#000",
      fontSize: 13, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase",
      padding: 14, border: "none", borderRadius: 16, width: "100%",
      boxShadow: "0 4px 20px rgba(42,191,191,0.35), inset 0 1px 0 rgba(255,255,255,0.25)",
      display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
      cursor: "pointer", transition: "transform 0.1s ease",
      ...style,
    }}
    onMouseDown={e => e.currentTarget.style.transform = "scale(0.98)"}
    onMouseUp={e => e.currentTarget.style.transform = "scale(1)"}
    onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}>
      {icon}
      {children}
    </button>
  );
}

function GhostButton({ children, onClick, style }) {
  return (
    <button onClick={onClick} style={{
      background: "rgba(255,255,255,0.04)",
      color: "#f0f0f0",
      fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase",
      padding: 16, border: "0.5px solid rgba(255,255,255,0.2)", borderRadius: 6,
      width: "100%", cursor: "pointer",
      ...style,
    }}>{children}</button>
  );
}

// Icons — 22×22, stroke 1.4
function Ic({ d, s = 1.4, fill = false, active = false }) {
  const c = active ? TURQ : "rgba(255,255,255,0.35)";
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={fill ? c : "none"}>
      <path d={d} stroke={fill ? undefined : c} strokeWidth={s} strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

Object.assign(window, { TURQ, GLASS, GLASS_SM, Eyebrow, Chip, PrimaryButton, GhostButton, Ic });
