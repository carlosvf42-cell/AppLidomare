# Lidomare App — UI Kit

Click-thru recreation of the Lidomare Health App mobile PWA.

## Files
- `index.html` — click-thru prototype (Login → Home → Contenido → Citas → Perfil)
- `Shell.jsx` — 430px app frame + ambient glass background + bottom nav
- `Primitives.jsx` — Glass, GlassSm, Eyebrow, Chip, Icon set, Button
- `LoginScreen.jsx` — login form (serif hero + underline inputs)
- `HomeScreen.jsx` — hero photo, welcome, week calendar, streak, próximo entrenamiento
- `ContenidoScreen.jsx` — biblioteca section cards
- `CitasScreen.jsx` — Salonized + WhatsApp hero cards (Barlow Condensed)
- `PerfilScreen.jsx` — avatar, email, admin, sign out
- `Splash.jsx` — splash card shown briefly at boot

The prototype routes via simple React state — no real auth / data.
