function LoginScreen({ onLogin }) {
  const [email, setEmail] = React.useState("carlos@lidomare.es");
  const [pw, setPw] = React.useState("••••••••");
  return (
    <div style={{ minHeight: "100%", background: "#080808", position: "relative", overflow: "hidden",
      display: "flex", alignItems: "center", justifyContent: "center", padding: "0 32px" }}>
      <div aria-hidden style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: "-15%", left: "-20%", width: "65%", height: "65%", borderRadius: "50%",
          background: "radial-gradient(circle, rgba(42,191,191,0.13) 0%, transparent 70%)", filter: "blur(80px)" }} />
        <div style={{ position: "absolute", bottom: "5%", right: "-15%", width: "55%", height: "50%", borderRadius: "50%",
          background: "radial-gradient(circle, rgba(42,191,191,0.08) 0%, transparent 70%)", filter: "blur(100px)" }} />
      </div>
      <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 390,
        display: "flex", flexDirection: "column", gap: 48 }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 18, letterSpacing: "0.4em", color: "#333", textTransform: "uppercase" }}>Lidomare</div>
          <div style={{ fontSize: 32, letterSpacing: "0.3em", fontWeight: 300, color: "#f0f0f0", textTransform: "uppercase",
            fontFamily: "'Cormorant Garamond', Georgia, serif", marginTop: 4 }}>HEALTH APP</div>
          <div style={{ fontSize: 9, letterSpacing: "0.3em", color: "#2abfbf", textTransform: "uppercase", marginTop: 6 }}>Precision Wellness</div>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); onLogin(); }} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          {["Usuario", "Contraseña"].map((label, i) => (
            <div key={label}>
              <label style={{ display: "block", fontSize: 8, letterSpacing: "0.25em",
                color: "rgba(255,255,255,0.25)", textTransform: "uppercase", marginBottom: 8 }}>{label}</label>
              <input
                type={i === 0 ? "email" : "password"}
                value={i === 0 ? email : pw}
                onChange={e => i === 0 ? setEmail(e.target.value) : setPw(e.target.value)}
                style={{ background: "transparent", border: "none",
                  borderBottom: "0.5px solid rgba(255,255,255,0.15)", borderRadius: 0,
                  color: "#f0f0f0", fontSize: 12, letterSpacing: "0.15em",
                  padding: "12px 0", width: "100%", outline: "none" }}/>
            </div>
          ))}
          <button type="submit" style={{
            background: "rgba(255,255,255,0.04)", border: "0.5px solid rgba(255,255,255,0.2)",
            borderRadius: 4, color: "#f0f0f0", fontSize: 10, letterSpacing: "0.25em",
            textTransform: "uppercase", padding: 16, width: "100%", marginTop: 8, cursor: "pointer" }}>Acceder</button>
        </form>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <button type="button" style={{ background: "none", border: "none", padding: 0,
            fontSize: 9, letterSpacing: "0.2em", color: "#333", textTransform: "uppercase", cursor: "pointer" }}>
            Olvidé mi contraseña
          </button>
        </div>
        <div style={{ textAlign: "center", fontSize: 8, color: "#1a1a1a", letterSpacing: "0.2em" }}>
          <div>LM · PLAYAMAR · TORREMOLINOS</div>
          <div style={{ marginTop: 3 }}>SEC_CONN: ACTIVE</div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { LoginScreen });
