---
name: lidomare-design
description: Use this skill to generate well-branded interfaces and assets for Lidomare Health App (Lidomare Health & Fitness Club, Playamar, Torremolinos — powered by Antifrágil®), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files (`colors_and_type.css`, `assets/`, `preview/`, `ui_kits/app/`).

The Lidomare aesthetic is tight: pure-black shell, one turquoise accent (`#2abfbf`), liquid-glass cards, 0.5px hairlines, all-caps tracked micro-labels, Inter + Cormorant Garamond + Barlow Condensed. Mobile-first 430px shell. Never add emoji, never invent chromatic colors, never use thick borders.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out of `assets/` and `ui_kits/app/` and create static HTML files for the user to view. Import `colors_and_type.css` for tokens or copy the relevant variables. Use the icon vocabulary in `preview/brand-icons.html` as reference — re-author inline SVG, do not pull Lucide/Heroicons.

If working on production code, copy assets and read the rules in README.md (Content Fundamentals + Visual Foundations + Iconography) to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, surface, length, tone), and act as an expert designer who outputs HTML artifacts or production code, depending on the need.
